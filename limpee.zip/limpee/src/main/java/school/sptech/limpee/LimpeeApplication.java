package school.sptech.limpee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LimpeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(LimpeeApplication.class, args);
	}

}

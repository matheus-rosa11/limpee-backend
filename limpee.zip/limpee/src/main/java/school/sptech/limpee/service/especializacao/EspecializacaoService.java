package school.sptech.limpee.service.especializacao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import school.sptech.limpee.api.repository.especializacao.EspecializacaoRepository;
import school.sptech.limpee.service.especializacao.dto.EspecializacaoDto;

@Service
public class EspecializacaoService {

    @Autowired
    private EspecializacaoRepository especializacaoRepository;
    public void cadastrar(EspecializacaoDto especializacaoDto) {

    }
}

package school.sptech.limpee.service.especializacao.dto;

import lombok.Data;

@Data
public class EspecializacaoCriacaoDto {
    private long idUsuario;
    private long idEspecialidade;
}

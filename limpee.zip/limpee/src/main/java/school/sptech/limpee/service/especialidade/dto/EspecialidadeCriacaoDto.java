package school.sptech.limpee.service.especialidade.dto;

public class EspecialidadeCriacaoDto {
    private String especialidade;

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }
}

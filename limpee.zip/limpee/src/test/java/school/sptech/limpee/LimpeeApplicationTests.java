package school.sptech.limpee;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LimpeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
